CPYTHON_LOCATION = "/opt/anaconda3/bin/python3"
CPYTHON_FILES_LOCATION = "/opt/topspin3.5pl7/exp/stan/nmr/py/user/CPython/"