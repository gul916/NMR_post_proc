import numpy as np

np.show_config()